package com.example.semesterproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Nullable;

public class ProfileEdit extends AppCompatActivity {

    EditText mUsername, mEmail, mPassword, mConfirmPassword;
    Button mChangeUsername, mChangeEmail, mChangePassword, mHome;
    FirebaseFirestore mFirestore;
    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_edit);

        mUsername = findViewById(R.id.edtUsername);
        mEmail = findViewById(R.id.edtEmail);
        mPassword = findViewById(R.id.edtPassword);
        mConfirmPassword = findViewById(R.id.edtConfirmPassword);
        mChangeUsername = findViewById(R.id.btnUsername);
        mChangeEmail = findViewById(R.id.btnEmail);
        mChangePassword = findViewById(R.id.btnPassword);
        mHome = findViewById(R.id.btnHome);
        mFirestore = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();

        mChangeUsername.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mUsername.getText().toString().trim().equals("")) {
                    mUsername.setError("Username cannot be left blank");
                }
                else {
                    final String username = mUsername.getText().toString().trim();
                    final DocumentReference docRef = mFirestore.collection("users").document(mAuth.getUid());
                    docRef.addSnapshotListener(new EventListener<DocumentSnapshot>() {
                        @Override
                        public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException e) {
                            Map<String, Object> profile = new HashMap<>();
                            profile.put("username", username);
                            profile.put("email", documentSnapshot.getString("email"));
                            profile.put("password", documentSnapshot.getString("password"));
                            docRef.set(profile);
                        }
                    });
                }
            }
        });

        mChangePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mPassword.getText().toString().trim().equals("")) {
                    mPassword.setError("Password cannot be left blank");
                    if (mConfirmPassword.getText().toString().trim().equals("")) {
                        mConfirmPassword.setError("Confirm Password cannot be left blank");
                    }
                }
                else if(mConfirmPassword.getText().toString().trim().equals("")) {
                    mConfirmPassword.setError("Confirm Password cannot be left blank");
                }
                else if (!mPassword.getText().toString().trim().equals(mConfirmPassword.getText().toString().trim())) {
                    mConfirmPassword.setError("Passwords must match");
                }
                else {
                    final String password = mPassword.getText().toString().trim();
                    final DocumentReference docRef = mFirestore.collection("users").document(mAuth.getUid());
                    docRef.addSnapshotListener(new EventListener<DocumentSnapshot>() {
                        @Override
                        public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException e) {
                            Map<String, Object> profile = new HashMap<>();
                            profile.put("username", documentSnapshot.getString("username"));
                            profile.put("email", documentSnapshot.getString("email"));
                            profile.put("password", password);
                            docRef.set(profile);
                            mAuth.getCurrentUser().updatePassword(password);
                        }
                    });
                }
            }
        });

        mChangeEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mEmail.getText().toString().trim().equals("")) {
                    mEmail.setError("Email cannot be left blank");
                }
                else {
                    final String email = mEmail.getText().toString().trim();
                    final DocumentReference docRef = mFirestore.collection("users").document(mAuth.getUid());
                    docRef.addSnapshotListener(new EventListener<DocumentSnapshot>() {
                        @Override
                        public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException e) {
                            Map<String, Object> profile = new HashMap<>();
                            profile.put("username", documentSnapshot.getString("username"));
                            profile.put("email", email);
                            profile.put("password", documentSnapshot.getString("password"));
                            docRef.set(profile);
                            mAuth.getCurrentUser().updateEmail(email);
                        }
                    });
                }
            }
        });

    }
}