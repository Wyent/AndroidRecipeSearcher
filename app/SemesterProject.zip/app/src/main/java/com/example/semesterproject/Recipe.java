package com.example.semesterproject;

import com.google.gson.annotations.SerializedName;

public class Recipe {
    private int id;                 //id# of recipe
    private int likes;               //# of likes of the recipe
    @SerializedName("title")
    private String name;            //name of the recipe
    private String image;           //image url of recipe

    public int getId(){
        return id;
    }
    public String getName(){
        return name;
    }
    public String getImage(){
        return image;
    }

    public Recipe(String name, String image, int likes) {
        this.name = name;
        this.image = image;
        this.likes = likes;
    }

    public int getLikes() {
        return likes;
    }
}
